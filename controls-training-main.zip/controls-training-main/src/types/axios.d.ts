type ApiResponseType = {
  data: {
    posts: VideoType[];
  };
};
