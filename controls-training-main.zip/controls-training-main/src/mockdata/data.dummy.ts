export const data = [
    {
    id: "1",
    title: "4-1-1-1",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-1/hls/1080_4-1-1-Part1.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-1/4-1-1-Part1-Thumbnail.jpg",
    feedback: false,
  },  
  {
    id: "2",
    title: "4-1-1-2",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-1/hls/1080_4-1-1-Part2.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-1/4-1-1-Part2-Thumbnail.jpg",
    feedback: false,
  }, 
  {
    id: "3",
    title: "4-1-2-1",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-2/hls/1080_4-1-2-Part1.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-2/4-1-2-Part1-Thumbnail.jpg",
    feedback: false,
  }, 
  {
    id: "4",
    title: "4-1-2-2",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-2/hls/1080_4-1-2-Part2.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-2/4-1-2-Part2-Thumbnail.jpg",
    feedback: false,
  }, 
  {
    id: "9",
    title: "4-1-7",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-7/hls/1080_4-1-7-Final.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-7/4-1-7-Final-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "5",
    title: "4-1-2-3",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-2/hls/1080_4-1-2-Part3.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-2/4-1-2-Part3-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "10",
    title: "4-1-8",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-8/hls/1080_4-1-8-Final.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-8/4-1-8-Final-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "6",
    title: "4-1-3-1",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-3/hls/1080_4-1-3-Part1.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-3/4-1-3-Part1-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "7",
    title: "4-1-16-1",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-16/hls/1080_4-1-16-Part1.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-16/4-1-16-Part1-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "7",
    title: "4-1-3-2",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-3/hls/1080_4-1-3-Part2.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-3/4-1-3-Part2-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "11",
    title: "4-1-10",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-10/hls/1080_4-1-10-Final.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-10/4-1-10_Thumbnail.jpg",
    feedback: false,
  },    
  {
    id: "8",
    title: "4-1-3-3",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-3/hls/1080_4-1-3-Part3.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-3/4-1-3-Part3-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "7",
    title: "4-1-16-2",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-16/hls/1080_4-1-16-Part2.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-16/4-1-16-Part2-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "12",
    title: "4-1-11-1",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-11/hls/1080_4-1-11-Part1.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-11/4-1-11-Part1-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "6",
    title: "4-1-4-1",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-4/hls/1080_4-1-4-Part1.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-4/4-1-4-Part1-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "13",
    title: "4-1-11-2",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-11/hls/1080_4-1-11-Final-Part2.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-11/4-1-11-Part2-Thumbnail.jpg",
    feedback: false,
  },
  {
    id: "6",
    title: "4-1-4-2",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-4/hls/1080_4-1-4-Part2.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-4/4-1-4-Part2-Thumbnail.jpg",
    feedback: false,
  },             
  {
    id: "14",
    title: "4-1-12",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-12/hls/1080_4-1-12-Final.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-12/4-1-12-Thumbnail.jpg",
    feedback: false,
   },
  {
    id: "6",
    title: "4-1-4-3",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-4/hls/1080_4-1-4-Part3.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-4/4-1-4-Part3-Thumbnail.jpg",
    feedback: false,
  }, 
  {
    id: "15",
    title: "4-1-13",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
    mediaUrl: "https://c3619z4506.r-cdn.com/4-1-13/hls/1080_4-1-13-Final.m3u8",
    thumbnail: "https://c3619z4506.r-cdn.com/4-1-13/4-1-13-Thumbnail.jpg",
    feedback: false,
   }
  //,
  // {
  //   id: "4",
  //   title: "4-1-3 Part 1",
  //   description:
  //     "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
  //   mediaUrl: "https://c3619z4506.r-cdn.com/4-1-3/hls/1080_4-1-3-Part1-r2-Draft.m3u8",
  //   thumbnail: "https://c3619z4506.r-cdn.com/4-1-3/4-1-3-Part1-r2-Thumbnail.jpg",
  //   feedback: false,
  // },
  
  // {
  //   id: "5",
  //   title: "4-1-3 Part 2",
  //   description:
  //     "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
  //   mediaUrl: "https://c3619z4506.r-cdn.com/4-1-3/hls/1080_4-1-3-Part2-r2-Draft.m3u8",
  //   thumbnail: "https://c3619z4506.r-cdn.com/4-1-3/4-1-3-Part2-r2-Thumbnail.jpg",
  //   feedback: false,
  // },
  // {
  //   id: "6",
  //   title: "4-1-3 Part 3",
  //   description:
  //     "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
  //   mediaUrl: "https://c3619z4506.r-cdn.com/4-1-3/hls/1080_4-1-3-Part3-r2-Draft.m3u8",
  //   thumbnail: "https://c3619z4506.r-cdn.com/4-1-3/4-1-3-Part3-r2-Thumbnail.jpg",
  //   feedback: false,
  // }
  //   {
  //     id: "4",
  //     title: "Random Title",
  //     description:
  //       "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
  //     mediaUrl: "https://c3619z4506.r-cdn.com/IMG_2687.MOV",
  //     thumbnail: "https://cdn.gro.care/53d5e59f202d_1683463530883.jpeg",
  //   },
  //   {
  //     id: "5",
  //     title: "Random Title",
  //     description:
  //       "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet enim nec libero faucibus imperdiet. Nam auctor commodo nulla nec finibus. Etiam gravida mauris at neque scelerisque, eu euismod ex sodales. In at risus at ipsum blandit ultricies a a ipsum. Integer euismod consectetur dignissim. ",
  //     mediaUrl: "https://c3619z4506.r-cdn.com/IMG_2688.MOV",
  //     thumbnail: "https://cdn.gro.care/53d5e59f202d_1683463530883.jpeg",
  //   },
];
